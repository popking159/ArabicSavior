# -*- coding: utf-8 -*-
from enigma import getDesktop, addFont, eActionMap, eRCInput  # pyright: ignore[reportMissingImports]
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.ConfigList import ConfigListScreen
from Components.config import config, getConfigListEntry, configfile
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from os import path as os_path
from .config import PLUGINPATH
from .logger import logdata, dellog
from .updater import Updater, VER
from .__init__ import _


def DreamOS():
    if os_path.exists("/var/lib/dpkg/status"):
        return DreamOS


sz_w = getDesktop(0).size().width()


def restartEnigma(session, answer=None):
    if answer:
        session.open(TryQuitMainloop, 3)


class KeyCaptureScreen(Screen):
    skin = """<screen position="center,center" size="500,100" title="اضغط الزر المراد تعيينه" flags="wfNoBorder">
    <widget name="label" position="10,10" size="480,80" font="Regular;28" halign="center" valign="center"/>
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self["label"] = Label(_("اضغط أي زر من الريموت ..."))
        self.key_caught = False
        self["actions"] = ActionMap(["SetupActions", "WizardActions", "MenuActions"],
                                    {
            "cancel": self.close,
            "ok": self.dummy,
            "up": self.dummy,
            "down": self.dummy,
            "left": self.dummy,
            "right": self.dummy
        }, -100)
        self.onFirstExecBegin.append(self.startHook)
        self.onClose.append(self.stopHook)

    def dummy(self):
        return 1

    def startHook(self):
        try:
            self.hook_slot = eActionMap.getInstance().bindAction(
                '', -2147483648, self.keyPressed)
        except Exception:
            pass

    def stopHook(self):
        try:
            if hasattr(self, 'hook_slot'):
                self.hook_slot = None
                eActionMap.getInstance().unbindAction('', self.keyPressed)
        except Exception:
            pass

    def keyPressed(self, key, flag):
        if flag == 1:
            keyname = self.resolveKeyName(key)
            if keyname:
                if keyname in ("KEY_EXIT", "KEY_ESC"):
                    self.close(None)
                    return 1
                if not self.key_caught:
                    self.key_caught = True
                    self.close(keyname)
                    return 1
        return 1

    def resolveKeyName(self, key):
        try:
            from keyids import KEYIDS
            for name, k_id in KEYIDS.items():
                if k_id == key:
                    return name
        except Exception:
            pass
        try:
            rc = eRCInput.getInstance()
            if hasattr(rc, 'getLabel'):
                return rc.getLabel(key)
            if hasattr(rc, 'getKeyName'):
                return rc.getKeyName(key)
        except Exception:
            pass
        return None


class ArabicSaviorSetup(ConfigListScreen, Screen):
    if sz_w == 1280:
        skin = """
<screen name="ArabicSaviorSetup" position="center,center" size="620,398" title="  RAED منقذ اللغه العربيه د.محمود فرج - تحديث   " flags="wfNoBorder" >
<widget source="Title" position="5,5" size="610,30" render="Label" font="Regular;25" foregroundColor="#00ffa500" backgroundColor="#16000000" transparent="1" halign="center"/>
<widget name="config" position="13,45" size="584,119" scrollbarMode="showOnDemand"/>
<eLabel text="" foregroundColor="#00ff2525" backgroundColor="#00ff2525" size="150,3" position="8,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#00389416" backgroundColor="#00389416" size="150,3" position="163,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#00bab329" backgroundColor="#00bab329" size="150,3" position="318,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#000000ff" backgroundColor="#000000ff" size="150,3" position="473,394" zPosition="-10"/>
<widget render="Label" source="key_red" position="8,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_green" position="163,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_yellow" position="318,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_blue" position="473,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget name="Picture" position="23,174" size="570,150" zPosition="5" alphatest="on"/>
</screen>"""
    else:
        if DreamOS():
            skin = """
<screen name="ArabicSaviorSetup" position="center,center" size="840,560" title="  RAED منقذ اللغه العربيه  د.محمود فرج - تحديث   " flags="wfNoBorder" >
<widget source="Title" position="5,5" size="826,50" render="Label" font="Regular;28" foregroundColor="#00ffa500" backgroundColor="#16000000" transparent="1" halign="center"/>
<widget name="config" position="28,70" size="780,250" scrollbarMode="showOnDemand"/>
<eLabel text="" foregroundColor="#00ff2525" backgroundColor="#00ff2525" size="200,5" position="8,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00389416" backgroundColor="#00389416" size="200,5" position="213,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00bab329" backgroundColor="#00bab329" size="200,5" position="418,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#000000ff" backgroundColor="#000000ff" size="200,5" position="623,550" zPosition="-10"/>
<widget render="Label" source="key_red" position="8,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_green" position="213,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_yellow" position="418,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_blue" position="623,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget name="Picture" position="126,311" size="570,150" zPosition="5" alphatest="on"/>
</screen>"""
        else:
            skin = """
<screen name="ArabicSaviorSetup" position="center,center" size="840,560" title="  RAED منقذ اللغه العربيه  د.محمود فرج - تحديث   " flags="wfNoBorder" >
<widget source="Title" position="5,5" size="826,50" render="Label" font="Regular;28" foregroundColor="#00ffa500" backgroundColor="#16000000" transparent="1" halign="center"/>
<widget name="config" font="Regular;28" secondfont="Regular;26" itemHeight="45" position="28,80" size="780,250" scrollbarMode="showOnDemand"/>
<eLabel text="" foregroundColor="#00ff2525" backgroundColor="#00ff2525" size="200,5" position="8,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00389416" backgroundColor="#00389416" size="200,5" position="213,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00bab329" backgroundColor="#00bab329" size="200,5" position="418,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#000000ff" backgroundColor="#000000ff" size="200,5" position="623,550" zPosition="-10"/>
<widget render="Label" source="key_red" position="8,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_green" position="213,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_yellow" position="418,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_blue" position="623,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget name="Picture" position="126,311" size="570,150" zPosition="5" alphatest="on"/>
</screen>"""

    def __init__(self, session):
        dellog()
        Screen.__init__(self, session)
        self.session = session
        self.skin = ArabicSaviorSetup.skin
        self.configChanged = False
        list = []
        ConfigListScreen.__init__(self, list)
        self["config"].list = list
        self["key_red"] = StaticText(_("الغاء"))
        self["key_green"] = StaticText(_("حفظ"))
        self["key_yellow"] = StaticText(_("تفعيل اللغة"))
        self["key_blue"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {
            "cancel": self.keyClose,
            "green": self.keySave,
            "yellow": self.activate,
            "blue": self.captureKey,
        }, -1)

        self.set_active_value = config.ArabicSavior.active.value
        self.set_keyname_value = config.ArabicSavior.keyname.value
        self.set_fonts_value = config.ArabicSavior.fonts.value

        self["Picture"] = Pixmap()
        self.createConfigList()
        self.onLayoutFinish.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle("منقذ اللغة العربية إصدار %s" % VER)
        if config.ArabicSavior.updateonline.value:
            updater = Updater(self.session)
            updater.checkupdates()

    def createConfigList(self):
        self.configChanged = True
        self.set_active = getConfigListEntry(
            _(":تفعيل وتعطيل المنقذ العربي"), config.ArabicSavior.active)
        self.set_updateonline = getConfigListEntry(
            _(":تفعيل وتعطيل خاصية التحديث المباشر"), config.ArabicSavior.updateonline)
        self.set_keyname_enable = getConfigListEntry(
            _(":تفعيل وتعطيل خاصية الزر السريع"), config.ArabicSavior.keyname_enable)
        self.set_fonts = getConfigListEntry(
            _(":اختيار نوع الخط"), config.ArabicSavior.fonts)

        list = []
        list.append(self.set_active)
        list.append(self.set_updateonline)
        list.append(self.set_keyname_enable)
        if config.ArabicSavior.keyname_enable.value:
            self["key_blue"].setText("تعيين زر السريع")
        else:
            self["key_blue"].setText("")
        list.append(self.set_fonts)

        self["config"].list = list
        self["config"].l.setList(list)
        self["config"].onSelectionChanged.append(self.Picture)

    def Picture(self):
        try:
            cur = self["config"].getCurrent()
            if cur == self.set_fonts:
                preview = PLUGINPATH + "/images/preview/%s.png" % config.ArabicSavior.fonts.value
                preview = preview.replace(PLUGINPATH + "/fonts", "")
                if os_path.exists(preview):
                    self["Picture"].instance.setPixmapFromFile(preview)
                    self["Picture"].show()
                else:
                    logdata("Picture preview: No preview image")
            else:
                self["Picture"].hide()
        except Exception as error:
            logdata("Picture preview:", error)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.Picture()
        self.createConfigList()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createConfigList()
        self.Picture()

    def captureKey(self):
        if config.ArabicSavior.keyname_enable.value:
            self.session.openWithCallback(self.keyCaptured, KeyCaptureScreen)

    def keyCaptured(self, keyname=None):
        if keyname:
            config.ArabicSavior.keyname.value = keyname
            config.ArabicSavior.keyname.save()
            self.keySave()
            self.createConfigList()

    def activate(self):
        try:
            addFont(config.ArabicSavior.fonts.value, "ArabicFont", 100, 1)
            logdata("activate: arabic font added successfully")
        except Exception as error:
            logdata("activate:", error)
        self["key_red"].setText(_("الغاء"))
        self["key_green"].setText(_("حفظ"))
        self.setTitle("منقذ اللغة العربية إصدار %s" % VER)

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        try:
            addFont(config.ArabicSavior.fonts.value, "ArabicFont", 100, 1)
            logdata("activate: arabic font added successfully")
        except Exception as error:
            logdata("activate:", error)
        try:
            if os_path.exists("/usr/lib64/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"):
                keymap_path = "/usr/lib64/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"
            else:
                keymap_path = "/usr/lib/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"
            keyfile = open(keymap_path, "w")
            keyfile.write('<keymap>\n\t<map context="GlobalActions">\n\t\t<key id="%s" mapto="ArabicSavior" flags="m" />\n\t</map>\n</keymap>' %
                          config.ArabicSavior.keyname.value)
            keyfile.close()
        except Exception as error:
            logdata("keySave keymap error:", error)
        if self.set_active_value != config.ArabicSavior.active.value or \
                self.set_fonts_value != config.ArabicSavior.fonts.value or \
                self.set_keyname_value != config.ArabicSavior.keyname.value:
            self.session.openWithCallback(self.restart, MessageBox, _(
                "تم تغيير الإعدادات ، هل تريد إعادة تشغيل الانجيما الآن؟"))
        else:
            self.close(True)

    def restart(self, answer=None):
        if answer:
            restartEnigma(self.session, answer)
            return
        self.close(True)

    def keyClose(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

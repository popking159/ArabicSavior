# -*- coding: utf-8 -*-
from enigma import getDesktop, addFont, eActionMap, eRCInput  # pyright: ignore[reportMissingImports]
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Standby import TryQuitMainloop
from Components.ConfigList import ConfigListScreen
from Components.config import config, getConfigListEntry, configfile
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from os import path as os_path, remove as os_remove
from .config import PLUGINPATH, DEFAULTFont
from .logger import logdata, dellog
from .updater import Updater, VER
from .font_manager import import_local_fonts, download_online_fonts
from .__init__ import _


def DreamOS():
    if os_path.exists("/var/lib/dpkg/status"):
        return True
    return False


sz_w = getDesktop(0).size().width()


def restartEnigma(session, answer=None):
    if answer:
        session.open(TryQuitMainloop, 3)


class KeyCaptureScreen(Screen):
    skin = """<screen position="center,center" size="500,100" title="اضغط الزر المراد تعيينه" flags="wfNoBorder">
    <widget name="label" position="10,10" size="480,80" font="Regular;28" halign="center" valign="center"/>
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self["label"] = Label(_("اضغط أي زر من الريموت ..."))
        self.key_caught = False
        self["actions"] = ActionMap(["SetupActions", "WizardActions", "MenuActions"],
                                    {
            "cancel": self.close,
            "ok": self.dummy,
            "up": self.dummy,
            "down": self.dummy,
            "left": self.dummy,
            "right": self.dummy
        }, -100)
        self.onFirstExecBegin.append(self.startHook)
        self.onClose.append(self.stopHook)

    def dummy(self):
        return 1

    def startHook(self):
        try:
            self.hook_slot = eActionMap.getInstance().bindAction(
                '', -2147483648, self.keyPressed)
        except Exception:
            pass

    def stopHook(self):
        try:
            if hasattr(self, 'hook_slot'):
                self.hook_slot = None
                eActionMap.getInstance().unbindAction('', self.keyPressed)
        except Exception:
            pass

    def keyPressed(self, key, flag):
        if flag == 1:
            keyname = self.resolveKeyName(key)
            if keyname:
                if keyname in ("KEY_EXIT", "KEY_ESC"):
                    self.close(None)
                    return 1
                if not self.key_caught:
                    self.key_caught = True
                    self.close(keyname)
                    return 1
        return 1

    def resolveKeyName(self, key):
        try:
            from keyids import KEYIDS
            for name, k_id in KEYIDS.items():
                if k_id == key:
                    return name
        except Exception:
            pass
        try:
            rc = eRCInput.getInstance()
            if hasattr(rc, 'getLabel'):
                return rc.getLabel(key)
            if hasattr(rc, 'getKeyName'):
                return rc.getKeyName(key)
        except Exception:
            pass
        return None


class ArabicSaviorSetup(ConfigListScreen, Screen):
    if sz_w == 1280:
        skin = """
<screen name="ArabicSaviorSetup" position="center,center" size="620,398" title="  RAED منقذ اللغه العربيه د.محمود فرج - تحديث   " flags="wfNoBorder" >
<widget source="Title" position="5,5" size="610,30" render="Label" font="Regular;25" foregroundColor="#00ffa500" backgroundColor="#16000000" transparent="1" halign="center"/>
<widget name="config" position="13,45" size="584,150" scrollbarMode="showOnDemand"/>
<eLabel text="" foregroundColor="#00ff2525" backgroundColor="#00ff2525" size="150,3" position="8,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#00389416" backgroundColor="#00389416" size="150,3" position="163,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#00bab329" backgroundColor="#00bab329" size="150,3" position="318,394" zPosition="-10"/>
<eLabel text="" foregroundColor="#000000ff" backgroundColor="#000000ff" size="150,3" position="473,394" zPosition="-10"/>
<widget render="Label" source="key_red" position="8,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_green" position="163,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_yellow" position="318,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_blue" position="473,360" size="150,35" zPosition="5" valign="center" halign="left" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<!-- Added scale="1" so the 780px image scales down beautifully for HD -->
<widget name="Picture" position="25,200" size="570,150" zPosition="5" alphatest="blend" scale="1"/>
</screen>"""
    else:
        skin = """
<screen name="ArabicSaviorSetup" position="center,center" size="840,560" title="  RAED منقذ اللغه العربيه  د.محمود فرج - تحديث   " flags="wfNoBorder" >
<widget source="Title" position="5,5" size="826,50" render="Label" font="Regular;28" foregroundColor="#00ffa500" backgroundColor="#16000000" transparent="1" halign="center"/>
<widget name="config" font="Regular;28" secondfont="Regular;26" itemHeight="45" position="28,80" size="780,250" scrollbarMode="showOnDemand"/>
<eLabel text="" foregroundColor="#00ff2525" backgroundColor="#00ff2525" size="200,5" position="8,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00389416" backgroundColor="#00389416" size="200,5" position="213,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#00bab329" backgroundColor="#00bab329" size="200,5" position="418,550" zPosition="-10"/>
<eLabel text="" foregroundColor="#000000ff" backgroundColor="#000000ff" size="200,5" position="623,550" zPosition="-10"/>
<widget render="Label" source="key_red" position="8,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_green" position="213,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_yellow" position="418,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<widget render="Label" source="key_blue" position="623,515" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#16000000" font="Regular;28" transparent="1" foregroundColor="#00ffffff" shadowColor="black" shadowOffset="-1,-1"/>
<!-- Widened size to 780x150, recentered, and added scale="1" -->
<widget name="Picture" position="30,340" size="780,150" zPosition="5" alphatest="blend" scale="1"/>
</screen>"""

    def __init__(self, session):
        dellog()
        Screen.__init__(self, session)
        self.session = session
        self.skin = ArabicSaviorSetup.skin

        list = []
        ConfigListScreen.__init__(self, list)
        self["config"].list = list

        self["key_red"] = StaticText(_("الغاء"))
        self["key_green"] = StaticText(_("حفظ"))
        self["key_yellow"] = StaticText(_("تفعيل اللغة"))
        self["key_blue"] = StaticText(_("خيارات إضافية"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {
            "cancel": self.keyClose,
            "green": self.keySave,
            "yellow": self.activate,
            "blue": self.openExtras,
        }, -1)

        self.set_active_value = config.ArabicSavior.active.value
        self.set_keyname_value = config.ArabicSavior.keyname.value
        self.set_fonts_value = config.ArabicSavior.fonts.value
        self.set_scale_value = config.ArabicSavior.font_scale.value

        self["Picture"] = Pixmap()
        self.createConfigList()
        self.onLayoutFinish.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle("منقذ اللغة العربية إصدار %s" % VER)
        if config.ArabicSavior.updateonline.value:
            updater = Updater(self.session)
            updater.checkupdates()

    def createConfigList(self):
        self.set_active = getConfigListEntry(
            _(":تفعيل وتعطيل المنقذ العربي"), config.ArabicSavior.active)
        self.set_updateonline = getConfigListEntry(
            _(":تفعيل خاصية التحديث"), config.ArabicSavior.updateonline)
        self.set_keyname_enable = getConfigListEntry(
            _(":تفعيل خاصية الزر السريع"), config.ArabicSavior.keyname_enable)
        self.set_fonts = getConfigListEntry(
            _(":اختيار نوع الخط"), config.ArabicSavior.fonts)
        self.set_font_scale = getConfigListEntry(
            _(":حجم الخط (Scale)"), config.ArabicSavior.font_scale)

        list = [
            self.set_active,
            self.set_updateonline,
            self.set_keyname_enable,
            self.set_fonts,
            self.set_font_scale
        ]

        self["config"].list = list
        self["config"].l.setList(list)
        self["config"].onSelectionChanged.append(self.Picture)

    def Picture(self):
        try:
            cur = self["config"].getCurrent()
            if cur == self.set_fonts:
                font_filename = os_path.basename(
                    config.ArabicSavior.fonts.value)
                preview = os_path.join(
                    PLUGINPATH, "images", "preview", font_filename + ".png")

                # NEW: If image does not exist, generate it on the fly!
                if not os_path.exists(preview):
                    from .font_manager import generate_font_preview
                    generate_font_preview(
                        config.ArabicSavior.fonts.value, font_filename)

                if os_path.exists(preview):
                    self["Picture"].instance.setPixmap(
                        LoadPixmap(path=preview))
                    self["Picture"].show()
                else:
                    self["Picture"].hide()
            else:
                self["Picture"].hide()
        except Exception as e:
            logdata("Picture preview exception:", e)
            self["Picture"].hide()

    def keyLeft(self):
        # Preserve current selection index so the list doesn't jump
        current_index = self["config"].getCurrentIndex()
        ConfigListScreen.keyLeft(self)
        self.createConfigList()
        self["config"].setCurrentIndex(current_index)
        self.Picture()

    def keyRight(self):
        current_index = self["config"].getCurrentIndex()
        ConfigListScreen.keyRight(self)
        self.createConfigList()
        self["config"].setCurrentIndex(current_index)
        self.Picture()

    def openExtras(self):
        choices = [
            (_("تعيين الزر السريع (Quick Button)"), "quick"),
            (_("استيراد خط من مسار (TMP / USB)"), "import"),
            (_("تحميل خطوط من السيرفر (Online Store)"), "download"),
            (_("استعادة الإعدادات الافتراضية (Reset)"), "reset")
        ]
        self.session.openWithCallback(
            self.extrasCallback, ChoiceBox, title=_("خيارات إضافية:"), list=choices)

    def extrasCallback(self, choice):
        if choice:
            action = choice[1]
            if action == "quick":
                if config.ArabicSavior.keyname_enable.value:
                    self.session.openWithCallback(
                        self.keyCaptured, KeyCaptureScreen)
                else:
                    self.session.open(MessageBox, _(
                        "يرجى تفعيل خيار الزر السريع أولاً من القائمة"), MessageBox.TYPE_INFO)
            elif action == "import":
                import_local_fonts(self.session, self.createConfigList)
            elif action == "download":
                download_online_fonts(self.session, self.createConfigList)
            elif action == "reset":
                self.resetToDefaults()

    def resetToDefaults(self):
        config.ArabicSavior.active.value = True
        config.ArabicSavior.updateonline.value = True
        config.ArabicSavior.fonts.value = DEFAULTFont
        config.ArabicSavior.font_scale.value = "100"
        config.ArabicSavior.keyname_enable.value = False

        for km_path in ["/usr/lib64/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml",
                        "/usr/lib/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"]:
            if os_path.exists(km_path):
                try:
                    os_remove(km_path)
                except Exception:
                    pass

        config.ArabicSavior.save()
        configfile.save()
        self.createConfigList()
        self.session.open(MessageBox, _(
            "تمت استعادة الإعدادات الافتراضية بنجاح! يرجى إعادة التشغيل."), MessageBox.TYPE_INFO)

    def keyCaptured(self, keyname=None):
        if keyname:
            config.ArabicSavior.keyname.value = keyname
            config.ArabicSavior.keyname.save()
            self.keySave()
            self.createConfigList()

    def activate(self):
        try:
            scale = int(config.ArabicSavior.font_scale.value)
            addFont(config.ArabicSavior.fonts.value, "ArabicFont", scale, 1)
            logdata("activate: arabic font added successfully with scale", scale)
        except Exception as error:
            logdata("activate:", error)

        self["key_red"].setText(_("الغاء"))
        self["key_green"].setText(_("حفظ"))

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()

        try:
            scale = int(config.ArabicSavior.font_scale.value)
            addFont(config.ArabicSavior.fonts.value, "ArabicFont", scale, 1)
        except Exception:
            pass

        if config.ArabicSavior.keyname_enable.value:
            try:
                if os_path.exists("/usr/lib64/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"):
                    keymap_path = "/usr/lib64/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"
                else:
                    keymap_path = "/usr/lib/enigma2/python/Plugins/Extensions/ArabicSavior/keymap.xml"
                with open(keymap_path, "w") as keyfile:
                    keyfile.write('<keymap>\n\t<map context="GlobalActions">\n\t\t<key id="%s" mapto="ArabicSavior" flags="m" />\n\t</map>\n</keymap>' %
                                  config.ArabicSavior.keyname.value)
            except Exception as error:
                logdata("keySave keymap error:", error)

        if self.set_active_value != config.ArabicSavior.active.value or \
           self.set_fonts_value != config.ArabicSavior.fonts.value or \
           self.set_scale_value != config.ArabicSavior.font_scale.value or \
           self.set_keyname_value != config.ArabicSavior.keyname.value:
            self.session.openWithCallback(self.restart, MessageBox, _(
                "تم تغيير الإعدادات ، هل تريد إعادة تشغيل الانجيما الآن؟"))
        else:
            self.close(True)

    def restart(self, answer=None):
        if answer:
            restartEnigma(self.session, answer)
            return
        self.close(True)

    def keyClose(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

#!/bin/sh

# تحديد المسارات
SOURCE_DIR="/usr/lib/enigma2/python/Plugins/Extensions/ArabicSavior"
OUTPUT_FILE="/tmp/main.tar.gz"

# التحقق من وجود المجلد قبل الضغط
if [ -d "$SOURCE_DIR" ]; then
    echo "Starting compression and excluding .pyc/.pyo files..."
    
    # ضغط المجلد مع الحفاظ على المسار واستبعاد الملفات المحددة
    tar --exclude='*.pyc' --exclude='*.pyo' -czf "$OUTPUT_FILE" "$SOURCE_DIR"
    
    if [ $? -eq 0 ]; then
        echo "Success! Backup saved to: $OUTPUT_FILE"
    else
        echo "Error: Compression failed."
    fi
else
    echo "Error: Source directory does not exist."
fi

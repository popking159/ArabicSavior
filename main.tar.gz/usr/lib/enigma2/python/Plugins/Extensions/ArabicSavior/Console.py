#!/usr/bin/python
# -*- coding: utf-8 -*-
from .compat import PY3
from enigma import eConsoleAppContainer  # type: ignore
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Screens.MessageBox import MessageBox
from .__init__ import _


class Console(Screen):
    # Unified proportional skin for all resolutions (HD, FHD, WQHD, 4K)
    skin = '''
<screen position="center,center" size="80%,80%" title="Command execution..." backgroundColor="#16000000" flags="wfNoBorder">
    <eLabel text="Command execution..." font="Regular;35" size="96%,8%" position="2%,2%" foregroundColor="#00ffffff" backgroundColor="#16000000" zPosition="4"/>

    <widget name="text" position="2%,10%" size="96%,75%" backgroundColor="#16000000" foregroundColor="#00ffffff" font="Console;28"/>

    <eLabel position="2%,97%" size="28%,1%" backgroundColor="#00ff2525" zPosition="1"/>
    <eLabel position="36%,97%" size="28%,1%" backgroundColor="#00389416" zPosition="1"/>
    <eLabel position="70%,97%" size="28%,1%" backgroundColor="#000080ff" zPosition="1"/>

    <eLabel text="Cancel" position="2%,88%" zPosition="2" size="28%,8%" font="Regular;26" halign="center" valign="center" backgroundColor="#16000000" foregroundColor="#00ffffff" transparent="1"/>
    <eLabel text="Hide/Show" position="36%,88%" zPosition="2" size="28%,8%" font="Regular;26" halign="center" valign="center" backgroundColor="#16000000" foregroundColor="#00ffffff" transparent="1"/>
    <eLabel text="Restart GUI" position="70%,88%" zPosition="2" size="28%,8%" font="Regular;26" halign="center" valign="center" backgroundColor="#16000000" foregroundColor="#00ffffff" transparent="1"/>
</screen>'''

    def __init__(self, session, title='Console', cmdlist=None, finishedCallback=None, closeOnSuccess=False, showStartStopText=True, skin=None):
        Screen.__init__(self, session)
        self.finishedCallback = finishedCallback
        self.closeOnSuccess = closeOnSuccess
        self.showStartStopText = showStartStopText
        if skin:
            self.skinName = [skin, 'Console']
        self.errorOcurred = False
        self['text'] = ScrollLabel('')
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('Hide'))
        self["actions"] = ActionMap(["WizardActions", "DirectionActions", 'ColorActions'],
                                    {
            "ok": self.cancel,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "red": self.cancel,
            "green": self.toggleHideShow,
            "blue": self.restartenigma,
            "exit": self.cancel,
        }, -1)
        self.cmdlist = isinstance(cmdlist, list) and cmdlist or [cmdlist]
        self.newtitle = title == 'Console' and _('Console') or title
        self.cancel_msg = None
        self.onShown.append(self.updateTitle)
        self.container = eConsoleAppContainer()
        self.run = 0
        self.finished = False
        try:
            self.container.appClosed.append(self.runFinished)
            self.container.dataAvail.append(self.dataAvail)
        except Exception:
            self.container.appClosed_conn = self.container.appClosed.connect(
                self.runFinished)
            self.container.dataAvail_conn = self.container.dataAvail.connect(
                self.dataAvail)
        self.onLayoutFinish.append(self.startRun)

    def updateTitle(self):
        self.setTitle(self.newtitle)

    def startRun(self):
        if self.showStartStopText:
            self['text'].setText(_('Execution progress:') + '\n\n')
        if self.container.execute(self.cmdlist[self.run]):
            self.runFinished(-1)

    def runFinished(self, retval):
        if retval:
            self.errorOcurred = True
            self.show()
        self.run += 1
        if self.run != len(self.cmdlist):
            if self.container.execute(self.cmdlist[self.run]):
                self.runFinished(-1)
        else:
            self.show()
            self.finished = True
            if self.cancel_msg:
                self.cancel_msg.close()
            if self.showStartStopText:
                self['text'].appendText(_('Execution finished!!'))
            if self.finishedCallback is not None:
                self.finishedCallback()
            if not self.errorOcurred and self.closeOnSuccess:
                self.closeConsole()
            else:
                self['text'].appendText(_('\nPress OK or Exit to abort!'))
                self['key_red'].setText(_('Exit'))
                self['key_green'].setText('')

    def toggleHideShow(self):
        if self.finished:
            return
        if self.shown:
            self.hide()
        else:
            self.show()

    def cancel(self):
        if self.finished:
            self.closeConsole()
        else:
            self.cancel_msg = self.session.openWithCallback(self.cancelCallback, MessageBox, _(
                'Cancel execution?'), type=MessageBox.TYPE_YESNO, default=False)

    def cancelCallback(self, ret=None):
        self.cancel_msg = None
        if ret:
            try:
                self.container.appClosed.remove(self.runFinished)
                self.container.dataAvail.remove(self.dataAvail)
            except Exception:
                self.container.appClosed_conn = None
                self.container.dataAvail_conn = None
            self.container.kill()
            self.close()

    def closeConsole(self):
        if self.finished:
            try:
                self.container.appClosed.remove(self.runFinished)
                self.container.dataAvail.remove(self.dataAvail)
            except Exception:
                self.container.appClosed_conn = None
                self.container.dataAvail_conn = None
            self.close()
        else:
            self.show()

    def dataAvail(self, string):
        if PY3:
            self['text'].appendText(string.decode())
        else:
            self['text'].appendText(string)

    def restartenigma(self):
        from Screens.Standby import TryQuitMainloop
        self.session.open(TryQuitMainloop, 3)

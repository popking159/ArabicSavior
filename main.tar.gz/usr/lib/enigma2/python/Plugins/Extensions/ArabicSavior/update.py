# -*- coding: utf-8 -*-
import json
from twisted.web.client import getPage  # type: ignore
from Screens.MessageBox import MessageBox
from .Console import Console
from .metadata import PLUGIN_VERSION, PLUGIN_NAME
from .compat import PY3
from .logger import trace_error, logdata
from .__init__ import _

# URL to your JSON file
UPDATE_JSON_URL = b"https://raw.githubusercontent.com/popking159/ArabicSavior/main/update.json"


class PluginUpdater:
    def __init__(self, session, bg_check=False):
        self.session = session
        self.bg_check = bg_check
        self.update_data = None

    def check(self):
        try:
            getPage(UPDATE_JSON_URL, timeout=10).addCallback(
                self._parse_data).addErrback(self._err_back)
        except Exception:
            trace_error()

    def _err_back(self, error=None):
        logdata("PluginUpdater errBack", error)

    def _parse_data(self, data):
        try:
            if PY3 and isinstance(data, bytes):
                data = data.decode("utf-8")
            if data:
                self.update_data = json.loads(data)
                remote_v = self.update_data.get("version", "0.0.0")

                if self._is_newer(PLUGIN_VERSION, remote_v):
                    changelog = self.update_data.get(
                        "changelog", "Updates available.")
                    msg = _("إصدار جديد متاح لإضافة %s (v%s)\n\nالتحديثات:\n%s\n\nهل تريد التحديث الآن؟") % (
                        PLUGIN_NAME, remote_v, changelog
                    )
                    self.session.openWithCallback(
                        self._on_user_choice, MessageBox, msg, MessageBox.TYPE_YESNO)
                elif not self.bg_check:
                    # Only show this if the user manually triggered an update check
                    self.session.open(MessageBox, _(
                        "لا توجد تحديثات جديدة. أنت تستخدم أحدث إصدار."), MessageBox.TYPE_INFO)
        except Exception as e:
            logdata("PluginUpdater parseData exception", e)

    def _is_newer(self, local, remote):
        try:
            l_parts = [int(x) for x in local.split(".") if x.isdigit()]
            r_parts = [int(x) for x in remote.split(".") if x.isdigit()]
            return r_parts > l_parts
        except Exception:
            return False

    def _on_user_choice(self, answer):
        if answer and self.update_data and self.update_data.get("script_url"):
            cmd = "wget --no-check-certificate -qO - %s | bash" % self.update_data["script_url"]
            self.session.open(Console, title=_("Updating %s...") %
                              PLUGIN_NAME, cmdlist=[cmd], closeOnSuccess=False)

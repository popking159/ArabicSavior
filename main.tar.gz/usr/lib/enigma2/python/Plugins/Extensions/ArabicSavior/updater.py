# -*- coding: utf-8 -*-
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from os import path as os_path
from twisted.web.client import getPage  # pyright: ignore[reportMissingImports]
from Screens.MessageBox import MessageBox
from .compat import PY3
from .Console import Console
from .logger import trace_error, logdata
from .__init__ import _


def getversioninfo():
    currversion = "1.0"
    version_file = resolveFilename(
        SCOPE_PLUGINS, "Extensions/ArabicSavior/version")
    if os_path.exists(version_file):
        try:
            fp = open(version_file, "r").readlines()
            for line in fp:
                if "version" in line:
                    currversion = line.split("=")[1].strip()
        except Exception:
            pass
    return currversion


VER = getversioninfo()


class Updater:
    def __init__(self, session):
        self.session = session
        self.new_version = VER
        self.url = b"https://raw.githubusercontent.com/popking159/ArabicSavior/refs/heads/main/myinstaller.sh"

    def checkupdates(self):
        try:
            getPage(self.url, timeout=10).addCallback(
                self.parseData).addErrback(self.errBack)
        except Exception:
            trace_error()

    def checkupdates_bg(self):
        try:
            getPage(self.url, timeout=10).addCallback(
                self.parseData_bg).addErrback(self.errBack)
        except Exception:
            pass

    def errBack(self, error=None):
        logdata("errBack-error", error)

    def parseData(self, data):
        self._process_data(data)
        if float(VER) >= float(self.new_version):
            logdata("Updates", "No new version available")
        else:
            self.session.openWithCallback(self.install, MessageBox, _(
                "New version %s is available.\n\nDo you want to install now?") % self.new_version, MessageBox.TYPE_YESNO)

    def parseData_bg(self, data):
        self._process_data(data)
        if float(VER) < float(self.new_version):
            # Silent notification prompting for update on boot
            self.session.openWithCallback(self.install, MessageBox, _(
                "A new update for ArabicSavior (%s) is available!\nDo you want to update it now?") % self.new_version, MessageBox.TYPE_YESNO)

    def _process_data(self, data):
        try:
            if PY3 and isinstance(data, bytes):
                data = data.decode("utf-8")
            if data:
                for line in data.split("\n"):
                    if line.startswith("version"):
                        self.new_version = line.split("=")[1].strip()
                        break
        except Exception as e:
            logdata("parseData exception", e)

    def install(self, answer=False):
        try:
            if answer:
                cmdlist = [
                    "wget --no-check-certificate https://raw.githubusercontent.com/popking159/ArabicSavior/refs/heads/main/myinstaller.sh -O - | /bin/sh"]
                self.session.open(Console, title="Installing last update, enigma will be started after install",
                                  cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
        except Exception:
            trace_error()

    def myCallback(self, result=None):
        return

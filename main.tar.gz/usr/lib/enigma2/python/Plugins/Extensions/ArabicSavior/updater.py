# -*- coding: utf-8 -*-
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from os import path as os_path
from twisted.web.client import getPage  # pyright: ignore[reportMissingImports]
from Screens.MessageBox import MessageBox
from .compat import PY3
from .Console import Console
from .logger import trace_error, logdata
from .__init__ import _


def getversioninfo():
    currversion = "1.0"
    version_file = resolveFilename(
        SCOPE_PLUGINS, "Extensions/ArabicSavior/version")
    if os_path.exists(version_file):
        try:
            fp = open(version_file, "r").readlines()
            for line in fp:
                if "version" in line:
                    currversion = line.split("=")[1].strip()
        except Exception:
            pass
    return currversion


VER = getversioninfo()


class Updater:
    def __init__(self, session):
        self.session = session
        self.new_version = VER

    def checkupdates(self):
        try:
            url = b"https://raw.githubusercontent.com/fairbird/ArabicSavior/main/installer.sh"
            getPage(url, timeout=10).addCallback(
                self.parseData).addErrback(self.errBack)
        except Exception:
            trace_error()

    def errBack(self, error=None):
        logdata("errBack-error", error)

    def parseData(self, data):
        if PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version"):
                    self.new_version = line.split("=")[1]
        logdata("Current VER", VER)
        logdata("New VER", self.new_version)
        if float(VER) >= float(self.new_version):
            logdata("Updates", "No new version available")
        else:
            new_version = self.new_version
            self.session.openWithCallback(self.install, MessageBox, _(
                "New version %s is available.\n\nDo want ot install now.") % new_version, MessageBox.TYPE_YESNO)

    def install(self, answer=False):
        try:
            if answer:
                cmdlist = [
                    "wget https://raw.githubusercontent.com/fairbird/ArabicSavior/main/installer.sh -O - | /bin/sh"]
                self.session.open(Console, title="Installing last update, enigma will be started after install",
                                  cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
        except Exception:
            trace_error()

    def myCallback(self, result=None):
        return

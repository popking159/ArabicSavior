# -*- coding: utf-8 -*-
from Components.config import config, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigYesNo, ConfigText
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from os import path as os_path, listdir as os_listdir
from .logger import trace_error, logdata

PLUGINPATH = resolveFilename(SCOPE_PLUGINS, "Extensions/ArabicSavior")
GETPath = os_path.join(PLUGINPATH, "fonts")

DEFAULTFont = ""
if os_path.exists(os_path.join(PLUGINPATH, "fonts", "font_default.otf")):
    try:
        DEFAULTFont = os_path.join(PLUGINPATH, "fonts", "font_default.otf")
    except Exception:
        trace_error()
else:
    logdata("ArabicSavior: Missing DEFAULT Font")

fonts = []


def update_font_choices():
    global fonts
    fonts = []
    try:
        if os_path.exists(GETPath):
            for fontName in os_listdir(GETPath):
                fontNamePath = os_path.join(GETPath, fontName)
                if fontName.endswith(".ttf") or fontName.endswith(".otf"):
                    fonts.append((fontNamePath, fontName[:-4]))
    except Exception:
        trace_error()
    fonts = sorted(fonts, key=lambda x: x[1])
    config.ArabicSavior.fonts.setChoices(fonts)


# Initial load
try:
    if os_path.exists(GETPath):
        for fontName in os_listdir(GETPath):
            fontNamePath = os_path.join(GETPath, fontName)
            if fontName.endswith(".ttf") or fontName.endswith(".otf"):
                fonts.append((fontNamePath, fontName[:-4]))
except Exception:
    pass
fonts = sorted(fonts, key=lambda x: x[1])

# Configuration setup
config.ArabicSavior = ConfigSubsection()
config.ArabicSavior.active = ConfigEnableDisable(default=True)
config.ArabicSavior.updateonline = ConfigYesNo(default=True)
config.ArabicSavior.fonts = ConfigSelection(default=DEFAULTFont, choices=fonts)

# Added Font Scale Feature (50 to 150)
scale_choices = [(str(x), str(x)) for x in range(50, 160, 10)]
config.ArabicSavior.font_scale = ConfigSelection(
    default="100", choices=scale_choices)

config.ArabicSavior.keyname_enable = ConfigYesNo(default=False)
config.ArabicSavior.keyname = ConfigText(default="KEY_TEXT")

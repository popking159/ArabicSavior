# -*- coding: utf-8 -*-
import os
from twisted.web.client import getPage, downloadPage  # pyright: ignore[reportMissingImports]
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from .config import GETPath, PLUGINPATH, update_font_choices
from .compat import PY3
from .logger import trace_error, logdata
from .__init__ import _
from PIL import Image, ImageDraw, ImageFont  # pyright: ignore[reportMissingImports]


def generate_font_preview(font_path, font_name):
    """
    Generates a PNG preview of the font using PIL/Pillow.
    Uses pre-shaped and pre-reversed Unicode strings so no external Arabic libraries are needed!
    """
    # DELETED: from .config import PLUGINPATH (already imported globally)
    import os

    preview_dir = os.path.join(PLUGINPATH, "images", "preview")
    if not os.path.exists(preview_dir):
        os.makedirs(preview_dir)

    preview_path = os.path.join(preview_dir, font_name + ".png")

    try:
        img = Image.new('RGBA', (780, 150), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        try:
            font = ImageFont.truetype(font_path, 32)
        except IOError:
            return False

        line1 = "ﺎﻬﺒﺣﺃ ﺔﺿﺎﻳﺭ ﺕﺮﻬﻇ ﻰﻄﺳﻮﻟﺍ ﻥﻭﺮﻘﻟﺍ ﻰﻓ"
        line2 = "ﺓﺯﺭﺎﺒﻤﻟﺍ ﻢﻬﻟ ﻖﺤﻳ ﻥﺎﻛ ﻂﻘﻓ ﺀﻼﺒﻨﻟﺍ ﻥﺎﺳﺮﻔﻟﺍ"

        draw.text((10, 25), line1, font=font, fill=(255, 255, 255, 255))
        draw.text((10, 80), line2, font=font, fill=(255, 255, 255, 255))

        img.save(preview_path, "PNG")
        return True

    except ImportError:
        # DELETED: from .logger import logdata (already imported globally)
        logdata("generate_font_preview",
                "Pillow not installed! Run: opkg install python3-pillow")
        return False
    except Exception as e:
        # DELETED: from .logger import logdata (already imported globally)
        logdata("generate_font_preview error", str(e))
        return False


def import_local_fonts(session, callback_refresh):
    # Added common 'fonts' subfolders so it finds your files!
    search_paths = [
        "/tmp", "/tmp/fonts",
        "/media/usb", "/media/usb/fonts",
        "/media/hdd", "/media/hdd/fonts"
    ]
    found_fonts = []

    for path in search_paths:
        if os.path.exists(path):
            try:
                for file in os.listdir(path):
                    if file.lower().endswith(".ttf") or file.lower().endswith(".otf"):
                        found_fonts.append(
                            (file + " (" + path + ")", os.path.join(path, file)))
            except Exception:
                pass

    if not found_fonts:
        session.open(MessageBox, _(
            "لم يتم العثور على خطوط في مسارات /tmp أو /media"), MessageBox.TYPE_INFO)
        return

    def import_selected(choice):
        if choice:
            import shutil
            src = choice[1]
            filename = os.path.basename(src)
            dst = os.path.join(GETPath, filename)

            try:
                shutil.copy(src, dst)

                preview_status = generate_font_preview(dst, filename)

                update_font_choices()

                msg = _("تم استيراد الخط بنجاح!")
                if not preview_status:
                    msg += "\n" + \
                        _("(لم يتم إنشاء صورة المعاينة لعدم وجود مكتبة Pillow)")

                session.open(MessageBox, msg, MessageBox.TYPE_INFO)

                if callback_refresh:
                    callback_refresh()
            except Exception:
                trace_error()
                session.open(MessageBox, _(
                    "حدث خطأ أثناء الاستيراد"), MessageBox.TYPE_ERROR)

    session.openWithCallback(import_selected, ChoiceBox, title=_(
        "اختر الخط لاستيراده:"), list=found_fonts)


def download_online_fonts(session, callback_refresh):
    url = b"https://raw.githubusercontent.com/popking159/ArabicSavior/refs/heads/main/fonts.txt"

    def parse_fonts(data):
        if PY3 and isinstance(data, bytes):
            data = data.decode("utf-8")

        online_fonts = []
        if data:
            for line in data.split("\n"):
                if "|" in line:
                    name, link = line.split("|")
                    online_fonts.append((name.strip(), link.strip()))

        if not online_fonts:
            session.open(MessageBox, _(
                "لا توجد خطوط متاحة حالياً على السيرفر"), MessageBox.TYPE_INFO)
            return

        session.openWithCallback(download_selected, ChoiceBox, title=_(
            "اختر الخط للتحميل:"), list=online_fonts)

    def download_selected(choice):
        if choice:
            font_url = choice[1]
            filename = font_url.split("/")[-1]
            target_path = os.path.join(GETPath, filename)

            def dl_success(result):
                update_font_choices()
                session.open(MessageBox, _("تم تحميل الخط بنجاح!"),
                             MessageBox.TYPE_INFO)
                if callback_refresh:
                    callback_refresh()

            def dl_fail(error):
                session.open(MessageBox, _("فشل في تحميل الخط"),
                             MessageBox.TYPE_ERROR)

            if PY3 and isinstance(font_url, str):
                font_url = font_url.encode("utf-8")

            downloadPage(font_url, target_path).addCallback(
                dl_success).addErrback(dl_fail)

    def fetch_fail(error):
        session.open(MessageBox, _(
            "تعذر الاتصال بالسيرفر لجلب قائمة الخطوط"), MessageBox.TYPE_ERROR)

    getPage(url, timeout=10).addCallback(parse_fonts).addErrback(fetch_fail)

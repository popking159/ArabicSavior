PLUGIN_NAME = "ArabicSavior"
PLUGIN_VERSION = "2.9.0"
PLUGIN_DESCRIPTION = "إصلاح اللغة العربية وتحميل الخطوط"

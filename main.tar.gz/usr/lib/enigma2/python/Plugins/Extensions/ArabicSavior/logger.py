# -*- coding: utf-8 -*-
import sys
import traceback
from os import path as os_path, remove as os_remove


def trace_error():
    try:
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open("/tmp/ArabicSavior.log", "a"))
    except Exception:
        pass


def logdata(label_name="", data=None):
    try:
        data = str(data)
        fp = open("/tmp/ArabicSavior.log", "a")
        fp.write(str(label_name) + " : " + data + "\n")
        fp.close()
    except Exception:
        trace_error()
        pass


def dellog(label_name="", data=None):
    try:
        if os_path.exists("/tmp/ArabicSavior.log"):
            os_remove("/tmp/ArabicSavior.log")
    except Exception:
        pass

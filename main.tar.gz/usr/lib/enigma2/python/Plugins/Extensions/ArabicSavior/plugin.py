# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.config import config, configfile
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Screens.MessageBox import MessageBox
from enigma import addFont  # pyright: ignore[reportMissingImports]
from GlobalActions import globalActionMap

from .config import DEFAULTFont, fonts
from .logger import logdata
from .ui import ArabicSaviorSetup, restartEnigma
from .__init__ import _

try:
    from keymapparser import readKeymap
except Exception:
    from Components.ActionMap import loadKeymap as readKeymap


def panic(session, **kwargs):
    try:
        FONTSTYPE = config.ArabicSavior.fonts.value
        if FONTSTYPE not in [x[0] for x in fonts]:
            FONTSTYPE = DEFAULTFont
        config.ArabicSavior.active.value = True
        config.ArabicSavior.active.save()
        config.ArabicSavior.fonts.value = FONTSTYPE
        config.ArabicSavior.fonts.save()
        configfile.save()
        addFont(FONTSTYPE, "ArabicFont", 100, 1)
        logdata("panic: quick activation applied")
        session.openWithCallback(lambda answer: restartEnigma(session, answer), MessageBox, _(
            "تم تفعيل الإعدادات السريعة بنجاح\n\n هل تريد إعادة تشغيل الانجيما الآن؟"), MessageBox.TYPE_YESNO)
    except Exception as error:
        logdata("panic:", error)
        session.open(MessageBox, _("حدث خطأ أثناء التفعيل السريع"),
                     MessageBox.TYPE_ERROR, timeout=4)


def main(session, **kwargs):
    session.open(ArabicSaviorSetup)


def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        if session is not None:
            if config.ArabicSavior.keyname_enable.value:
                keymap = resolveFilename(
                    SCOPE_PLUGINS, "Extensions/ArabicSavior/keymap.xml")
                readKeymap(keymap)
                globalActionMap.actions['ArabicSavior'] = lambda: panic(
                    session)
        if config.ArabicSavior.active.value:
            try:
                addFont(config.ArabicSavior.fonts.value, "ArabicFont", 100, 1)
                logdata("activate: arabic font added successfully")
            except Exception as error:
                logdata("activate:", error)


def Plugins(**kwargs):
    list = []
    list.append(PluginDescriptor(
        where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))
    list.append(PluginDescriptor(icon="icon.png", name="المنقذ العربي",
                description="إصلاح اللغة العربية", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    list.append(PluginDescriptor(name="ArabicSavior تفعيل سريع المنقذ العربي",
                description="ArabicSavior تفعيل آخر إعدادات الخط بسرعة", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=panic))
    return list

# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.config import config, configfile
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Screens.MessageBox import MessageBox
from enigma import addFont, eTimer  # pyright: ignore[reportMissingImports]
from GlobalActions import globalActionMap

from .config import DEFAULTFont, fonts
from .logger import logdata
from .ui import ArabicSaviorSetup, restartEnigma
from .__init__ import _

try:
    from keymapparser import readKeymap
except Exception:
    from Components.ActionMap import loadKeymap as readKeymap

bg_timer = None


def panic(session, **kwargs):
    try:
        FONTSTYPE = config.ArabicSavior.fonts.value
        if FONTSTYPE not in [x[0] for x in fonts]:
            FONTSTYPE = DEFAULTFont

        config.ArabicSavior.active.value = True
        config.ArabicSavior.fonts.value = FONTSTYPE
        config.ArabicSavior.active.save()
        config.ArabicSavior.fonts.save()
        configfile.save()

        scale = int(config.ArabicSavior.font_scale.value)
        addFont(FONTSTYPE, "ArabicFont", scale, 1)

        logdata("panic: quick activation applied")
        session.openWithCallback(lambda answer: restartEnigma(session, answer), MessageBox, _(
            "تم تفعيل الإعدادات السريعة بنجاح\n\n هل تريد إعادة تشغيل الانجيما الآن؟"), MessageBox.TYPE_YESNO)
    except Exception as error:
        logdata("panic:", error)
        session.open(MessageBox, _("حدث خطأ أثناء التفعيل السريع"),
                     MessageBox.TYPE_ERROR, timeout=4)


def main(session, **kwargs):
    session.open(ArabicSaviorSetup)


def run_bg_check(session):
    if config.ArabicSavior.updateonline.value:
        from .updater import Updater
        updater = Updater(session)
        updater.checkupdates_bg()


def sessionstart(reason, session=None, **kwargs):
    if reason == 0 and session is not None:
        # 1. Load Custom Keymap if enabled
        if config.ArabicSavior.keyname_enable.value:
            keymap = resolveFilename(
                SCOPE_PLUGINS, "Extensions/ArabicSavior/keymap.xml")
            readKeymap(keymap)
            globalActionMap.actions['ArabicSavior'] = lambda: panic(session)

        # 2. Inject Font with selected scale
        if config.ArabicSavior.active.value:
            try:
                scale = int(config.ArabicSavior.font_scale.value)
                addFont(config.ArabicSavior.fonts.value,
                        "ArabicFont", scale, 1)
                logdata("activate: arabic font added successfully on boot")
            except Exception as error:
                logdata("activate:", error)

        # 3. Start Background Update Check (Delayed by 20 seconds to not slow boot)
        global bg_timer
        bg_timer = eTimer()
        try:
            bg_timer.callback.append(lambda: run_bg_check(session))
        except Exception:
            bg_timer.conn = bg_timer.timeout.connect(lambda: run_bg_check(session))
        bg_timer.start(20000, True)


def Plugins(**kwargs):
    list = []
    list.append(PluginDescriptor(
        where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))
    list.append(PluginDescriptor(icon="icon.png", name="المنقذ العربي",
                description="إصلاح اللغة العربية وتحميل الخطوط", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    list.append(PluginDescriptor(name="ArabicSavior تفعيل سريع المنقذ العربي",
                description="ArabicSavior تفعيل آخر إعدادات الخط بسرعة", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=panic))
    return list

# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.config import config, configfile
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Screens.MessageBox import MessageBox
from enigma import getDesktop, addFont, eTimer  # type: ignore
from GlobalActions import globalActionMap

from .config import DEFAULTFont, fonts
from .logger import logdata
from .ui import ArabicSaviorSetup, restartEnigma
from .__init__ import _

try:
    from keymapparser import readKeymap
except Exception:
    from Components.ActionMap import loadKeymap as readKeymap

bg_timer = None


def get_plugin_icon():
    try:
        width = getDesktop(0).size().width()
    except Exception:
        width = 1920  # Fallback to FHD if detection fails

    if width >= 3840:
        return "img/arabicsavior_4k_logo.png"
    elif width >= 2560:
        return "img/arabicsavior_wqhd_logo.png"
    elif width <= 1280:
        return "img/arabicsavior_hd_logo.png"
    else:
        return "img/arabicsavior_fhd_logo.png"


def panic(session, **kwargs):
    try:
        FONTSTYPE = config.ArabicSavior.fonts.value
        if FONTSTYPE not in [x[0] for x in fonts]:
            FONTSTYPE = DEFAULTFont

        config.ArabicSavior.active.value = True
        config.ArabicSavior.fonts.value = FONTSTYPE
        config.ArabicSavior.active.save()
        config.ArabicSavior.fonts.save()
        configfile.save()

        scale = int(config.ArabicSavior.font_scale.value)
        addFont(FONTSTYPE, "ArabicFont", scale, 1)

        logdata("panic: quick activation applied")
        session.openWithCallback(lambda answer: restartEnigma(session, answer), MessageBox, _(
            "تم تفعيل الإعدادات السريعة بنجاح\n\n هل تريد إعادة تشغيل الانجيما الآن؟"), MessageBox.TYPE_YESNO)
    except Exception as error:
        logdata("panic:", error)
        session.open(MessageBox, _("حدث خطأ أثناء التفعيل السريع"),
                     MessageBox.TYPE_ERROR, timeout=4)


def main(session, **kwargs):
    session.open(ArabicSaviorSetup)


def run_bg_check(session):
    if config.ArabicSavior.updateonline.value:
        from .update import PluginUpdater
        updater = PluginUpdater(session, bg_check=True)
        updater.check()


def sessionstart(reason, session=None, **kwargs):
    if reason == 0 and session is not None:
        if config.ArabicSavior.keyname_enable.value:
            keymap = resolveFilename(
                SCOPE_PLUGINS, "Extensions/ArabicSavior/keymap.xml")
            readKeymap(keymap)
            globalActionMap.actions['ArabicSavior'] = lambda: panic(session)

        if config.ArabicSavior.active.value:
            try:
                scale = int(config.ArabicSavior.font_scale.value)
                addFont(config.ArabicSavior.fonts.value,
                        "ArabicFont", scale, 1)
                logdata("activate: arabic font added successfully on boot")
            except Exception as error:
                logdata("activate:", error)

        global bg_timer
        bg_timer = eTimer()
        try:
            bg_timer.callback.append(lambda: run_bg_check(session))
        except Exception:
            bg_timer.conn = bg_timer.timeout.connect(
                lambda: run_bg_check(session))
        bg_timer.start(20000, True)


def Plugins(**kwargs):
    list = []
    list.append(PluginDescriptor(
        where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))

    # We now call our get_plugin_icon() function to pass the correctly sized image path
    list.append(PluginDescriptor(icon=get_plugin_icon(), name="المنقذ العربي",
                description="إصلاح اللغة العربية وتحميل الخطوط", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))

    list.append(PluginDescriptor(name="ArabicSavior تفعيل سريع المنقذ العربي",
                description="ArabicSavior تفعيل آخر إعدادات الخط بسرعة", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=panic))
    return list
